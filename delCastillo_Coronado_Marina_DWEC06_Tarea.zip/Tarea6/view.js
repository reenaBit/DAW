"use strict";

class AudiovisualDBView {
  constructor() {
    //Como propiedades los elementos de la página con los que tengamos que interactuar con javascript
    this.main = $("main"); //document.querySelector('main');
    this.header = $("header");
    this.fileWindow = null;
  }

  //Método que borra el contenido de main y añade el contenido inicial
  init(data) {
    this.main.empty();
    this.header.empty();

    //MENÚ
    let menuHeader = $(`
        <nav class="navbar navbar-expand-lg bg-light rounded" aria-label="Thirteenth navbar example">
            <div class="container-fluid">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarsExample11" aria-controls="navbarsExample11" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse d-lg-flex">
                    <a id="init" class="navbar-brand col-lg-3 me-0" href="#">Inicio</a>
                    <ul class="navbar-nav col-lg-6 justify-content-lg-center">
                       <li  class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"
                                aria-expanded="false">Modificar producciones</a>
                            <ul id="modifyDropdown" class="dropdown-menu">
                               <li><a id= "dropdownNewProd"  class="dropdown-item" href="#new-production">Nueva producción</a></li>
                               <li><a id= "dropdownDelProd"  class="dropdown-item" href="#">Eliminar producción</a></li>
                               <li><a id= "dropdownAddPerson"  class="dropdown-item" href="#">Añadir actores o directores a producción</a></li>
                            </ul>
                        </li>
                        <li  class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"
                                aria-expanded="false">Categorías</a>
                            <ul id="categoryDropdown" class="dropdown-menu">
                               
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"
                                aria-expanded="false">Actores</a>
                            <ul id="actorDropdown" class="dropdown-menu">
                                
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown"
                                aria-expanded="false">Directores</a>
                            <ul id="directorDropdown" class="dropdown-menu">
                               
                            </ul>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="#">Cerrar ventanas</a>
                        </li>
                        
                    </ul>
                </div>
            </div>
        </nav>
   `);
    //CONTAINER INICIO

    let containerInit = $(`
      </br></br><h2 class="pb-2 border-bottom">Categorías</h2>
        <div class="container px-4 py-5" id="hanging-icons">
          <table id="table">
            <div id="cat" class="row"></div>
          </table>
        </div>
    </br></br><h2 class="pb-2 border-bottom">Algunas producciones</h2>
      <div class="container px-4 py-5" id="hanging-icons">
       <table id="table">
        <div id="foot" ></div>
       </table>
      </div>
    `);
    this.header.append(menuHeader);
    this.main.append(containerInit);

    //CATEGORIAS
    let table = containerInit.find("#cat");
    let categoryDropdown = menuHeader.find("#categoryDropdown");

    let iteCat = data.categories;
    let category = iteCat.next();

    while (!category.done) {
      //Dropdown de categorias
      let categoriesSelect = $(`
            <li><a id= "${category.value.getId()}"  class="categories dropdown-item" href="#">${category.value.getName()}</a></li>
            `);
      //Contenedor de categorias del main del inicio
      let categoriesContainer = $(`
            <div class="col d-flex align-items-start">
            <div>
                <div>
                     <h3 class="fs-2">${category.value.getName()}</h3>
                        <h6>${category.value.getDescription()}</h6>
                        <a id= "${category.value.getId()}" class ="categories btn btn-primary" href="#">
                            Más información
                        </a>
                    </div>
                </div>
            </div>

              `);
      table.append(categoriesContainer);
      categoryDropdown.append(categoriesSelect);
      category = iteCat.next();
    }

    //ACTORES
    let actorDropdown = menuHeader.find("#actorDropdown");

    let iteAct = data.actors;
    let actor = iteAct.next();

    while (!actor.done) {
      //Dropdown de actores
      let actorsSelect = $(`
            <li><a id= "${actor.value.getId()}"  class="actorFile dropdown-item" href="#">${actor.value.getName()} ${actor.value.getLastName1()}</a></li>
            `);
      actorDropdown.append(actorsSelect);
      actor = iteAct.next();
    }

    //DIRECTORES
    let directorDropdown = menuHeader.find("#directorDropdown");

    let iteDir = data.directors;
    let director = iteDir.next();

    while (!director.done) {
      //Dropdown de directores
      let directorSelect = $(`
            <li><a id= "${director.value.getId()}"  class="directorFile dropdown-item" href="#">${director.value.getName()} ${director.value.getLastName1()}</a></li>
            `);
      directorDropdown.append(directorSelect);
      director = iteDir.next();
    }

    //PRODUCCIONES ALEATORIAS INICIO
    let arrayProductions = [];
    let iteProd = data.productions;
    for (let index = 0; index < 5; index++) {
      arrayProductions.push(iteProd.next().value);
    }

    let produccionesAleatorias = [];
    for (let i = 0; i < 3; i++) {
      let indice_aleatorio = Math.floor(
        Math.random() * arrayProductions.length
      );
      let elemento_aleatorio = arrayProductions[indice_aleatorio];
      produccionesAleatorias.push(elemento_aleatorio);
    }

    let foot = containerInit.find("#foot");
    for (let index = 0; index < produccionesAleatorias.length; index++) {
      let production = produccionesAleatorias[index];
      //Contenedor de producciones del main del inicio
      let productionsContainer = $(`
            
                     <h3 class="fs-2">${production.getTitle()}</h3>
                        <p>${production.getSynopsis()}</p>
                        <a id="${production.getId()}" href="#" class="productionFile btn btn-primary">
                        Más información
                        </a>
                    `);

      foot.append(productionsContainer);
    }
  }

  //Método para mostrar las producciones de una categoría en el main
  showCategories_Productions(data) {
    //  let iteCat = data.productionsCategory1;
    //  let category = iteCat.next();
    this.main.empty();
    let container = $(`<div class="container article-banner"><div class="row">
             <div class="table-responsive" id="shoppingcart-table">
                 <table class="table">
                     <thead>
                             <tr>
                                     <th scope="col">Producciones</th>
                        </tr>
                     </thead>
                     <tbody>
                     
                     </tbody>
                     <tfoot>
                     </tfoot>
                 </table>
             </div>
         </div></div>`);
    this.main.append(container);

    let tbody = container.find("tbody");

    let iteCat = data.productionsCategory;
    let production = iteCat.next();

    while (!production.done) {
      let p = $(
        `<ul><li><a id= "${production.value.getId()}" class="productionFile nav-link" href="#">${production.value.getTitle()}</a></li></ul>`
      );
      tbody.append(p);
      production = iteCat.next();
    }
  }

  //Método para mostrar la FICHA DE PRODUCCIÓN escogida
  showProductionFile(data) {
    this.main.empty();
    //Mostrar datos de la producción

    let prod = data.prodData;
    //Contenedor de la ficha
    let containerProd =
      $(`<div class="container article-banner"><div class="row">
        <div class="table-responsive" id="container-prod">
            <table class="table table-sm">
                <thead>
                </br>
                </br>
                    <tr id= "${prod.getId()}">
                      <th scope="col">Produccion</th>
                      <td >${prod.getTitle()}</td>
                      <th scope="col">Nacionalidad</th>
                      <td >${prod.getNacionality()}</td>
                      <th scope="col">Estreno</th>
                      <td >${prod.getPublication()}</td>
                      <th scope="col">Sinopsis</th>
                      <td >${prod.getSynopsis()}</td>
                   </tr>
                </thead>
                <tbody>
                </tbody>      
                <thead>
                <tr id="director">      
                 <th scope="col">Director</th>       
               </tr>
               <tr id="cast">          
               <th scope="col">Actores</th>
                </tr>
            </thead>
            </table>
            <div> 
              <button class="a-open" id="${prod.getId()}">Abrir en nueva ventana</button>
            </div>
        </div>
      </div>
    </div>`);
    this.main.append(containerProd);

    //Mostrar cast de actores
    let tfoot = containerProd.find("#cast");
    let iteCast = data.castData;
    let cast = iteCast.next();
    while (!cast.done) {
      let castContainer = $(`
            <tr>
            <td>
            <a id= "${cast.value.getId()}" class="actorFile nav-link" href="#">
            <i class="bi bi-file-earmark-plus"></i>
            ${cast.value.getName()} ${cast.value.getLastName1()}
            </a>
            </td>
            </tr>
            `);
      tfoot.append(castContainer);
      cast = iteCast.next();
    }

    //Mostrar al director de la producción
    let tfoot2 = containerProd.find("#director");
    let iteDir = data.directorData;
    let dir = iteDir.next();
    while (!dir.done) {
      let dirContainer = $(`
            <tr> 
            <td>
            <a id= "${dir.value.getId()}" class="directorFile nav-link" href="#" >
            <i class="bi bi-file-earmark-plus"></i>
            ${dir.value.getName()} ${dir.value.getLastName1()}
            </a>
            </td>      
            </tr>
            `);
      tfoot2.append(dirContainer);
      dir = iteDir.next();
    }
  }

  //Método para mostrar la FICHA DE ACTOR escogida
  showActorFile(data) {
    this.main.empty();
    let act = data.actorData;
    //Contenedor de la ficha
    let container = $(`<div class="container article-banner"><div class="row">
        <div class="table-responsive" id="shoppingcart-table">
            <table class="table table-sm">
                <thead>
                </br>
                </br>
                    <tr>
                      <th scope="row">Nombre</th>
                      <td >${act.getName()}</td>
                      <th scope="row">Primer Apellido</th>
                      <td >${act.getLastName1()}</td>
                      <th scope="row">Segundo Apellido</th>
                      <td >${act.getLastName2()}</td>
                      <th scope="row">Fecha de nacimiento</th>
                      <td >${act.getBorn()}</td>
                   </tr>
                </thead>
                <tbody>
                </tbody>      
                <thead>
                <tr >      
                 <th scope="col">Producciones</th>  
                 <td class="prodAct"></td>     
               </tr>
             </thead>
            </table>
            <div> 
            <button class="b-open" id="${act.getId()}">Abrir en nueva ventana</button>
          </div>
        </div>
      </div>
    </div>`);
    this.main.append(container);
    //Mostrar datos del actor

    let containerProd = container.find(".prodAct");
    let iteprod = data.prodData;
    let production = iteprod.next();
    //Mostrar lista de producciones
    while (!production.done) {
      let p = $(`
            <ul><li>
            <a id= "${production.value.getId()}" class="productionFile nav-link" href="#">
            ${production.value.getTitle()}
            </a>
            </li></ul>
            `);
      containerProd.append(p);
      production = iteprod.next();
    }
  }

  //Método para mostrar la FICHA DE DIRECTOR escogida
  showDirectorFile(data) {
    this.main.empty();
    let dir = data.directorData;
    //Datos del director
    let container = $(`<div class="container article-banner"><div class="row">
        <div class="table-responsive" id="shoppingcart-table">
            <table class="table table-sm">
                <thead>
                </br>
                </br>
                    <tr>
                      <th scope="row">Nombre</th>
                      <td >${dir.getName()}</td>
                      <th scope="row">Primer Apellido</th>
                      <td >${dir.getLastName1()}</td>
                      <th scope="row">Segundo Apellido</th>
                      <td >${dir.getLastName2()}</td>
                      <th scope="row">Fecha de nacimiento</th>
                      <td >${dir.getBorn()}</td>
                   </tr>
                </thead>
                <tbody>
                </tbody>      
                <thead>
                <tr >      
                 <th scope="col">Producciones</th>  
                 <td class="prodDir"></td>     
               </tr>
             </thead>
            </table>
            <div> 
            <button class="c-open" id="${dir.getId()}">Abrir en nueva ventana</button>
          </div>
        </div>
      </div>
    </div>`);
    this.main.append(container);
    //Mostrar datos del direcctor

    let containerProd = container.find(".prodDir");
    let iteprod = data.prodData;
    let production = iteprod.next();
    //Mostrar lista de producciones
    while (!production.done) {
      let p = $(`
            <ul><li>
            <a id= "${production.value.getId()}" class="productionFile nav-link" href="#">
            ${production.value.getTitle()}
            </a>
            </li></ul>
            `);
      containerProd.append(p);
      production = iteprod.next();
    }
  }
  //VENTANA con ficha de producciones
  showProductionFileInNewWindow(data, window) {
    let mainVentana = $(window.document).find("main");
    mainVentana.empty();
    let prod = data.prodData;
    window.document.title = `${prod.getTitle()}`;
    //Contenedor de la ficha
    let containerProd =
      $(`<div class="container article-banner"><div class="row">
        <div class="table-responsive" id="shoppingcart-table">
            <table class="table table-sm">
                <thead>
                </br>
                </br>
                    <tr id= "${prod.getId()}">
                      <th scope="col">Produccion</th>
                      <td >${prod.getTitle()}</td>
                      <th scope="col">Nacionalidad</th>
                      <td >${prod.getNacionality()}</td>
                      <th scope="col">Estreno</th>
                      <td >${prod.getPublication()}</td>
                      <th scope="col">Sinopsis</th>
                      <td >${prod.getSynopsis()}</td>
                   </tr>
                </thead>
                <tbody>
                </tbody>      
                <thead>
                <tr id="director">      
                 <th scope="col">Director</th>       
               </tr>
               <tr id="cast">          
               <th scope="col">Actores</th>
                </tr>
            </thead>
            </table>
            <div> 
            <button class="btn btn-primary text-uppercase m-2 px-4" onClick="window.close()">Cerrar</button>
            </div>
        </div>
      </div>
    </div>`);
    mainVentana.append(containerProd);

    //Mostrar cast de actores
    let tfoot = containerProd.find("#cast");
    let iteCast = data.castData;
    let cast = iteCast.next();
    while (!cast.done) {
      let castContainer = $(`
            <tr>
            <td>
            <a id= "${cast.value.getId()}" class="actorFile nav-link" href="#">
            ${cast.value.getName()} ${cast.value.getLastName1()}
            </a>
            </td>
            </tr>
            `);
      tfoot.append(castContainer);
      cast = iteCast.next();
    }

    //Mostrar al director de la producción
    let tfoot2 = containerProd.find("#director");
    let iteDir = data.directorData;
    let dir = iteDir.next();
    while (!dir.done) {
      let dirContainer = $(`
            <tr> 
            <td>
            <a id= "${dir.value.getId()}" class="directorFile nav-link" href="#" >
            ${dir.value.getName()} ${dir.value.getLastName1()}
            </a>
            </td>      
            </tr>
            `);
      tfoot2.append(dirContainer);
      dir = iteDir.next();
    }
    window.document.body.scrollIntoView();
  }

  //VENTANA para mostrar la FICHA DE ACTOR escogida
  showActorFileInNewWindow(data, window) {
    let mainVentana = $(window.document).find("main");
    mainVentana.empty();
    let act = data.actorData;
    window.document.title = `${act.getName()}${act.getLastName1()}`;
    //Contenedor de la ficha
    let container = $(`<div class="container article-banner"><div class="row">
        <div class="table-responsive" id="shoppingcart-table">
            <table class="table table-sm">
                <thead>
                </br>
                </br>
                    <tr>
                      <th scope="row">Nombre</th>
                      <td >${act.getName()}</td>
                      <th scope="row">Primer Apellido</th>
                      <td >${act.getLastName1()}</td>
                      <th scope="row">Segundo Apellido</th>
                      <td >${act.getLastName2()}</td>
                      <th scope="row">Fecha de nacimiento</th>
                      <td >${act.getBorn()}</td>
                   </tr>
                </thead>
                <tbody>
                </tbody>      
                <thead>
                <tr >      
                 <th scope="col">Producciones</th>  
                 <td class="prodAct"></td>     
               </tr>
             </thead>
            </table>
            <div> 
            <button class="btn btn-primary text-uppercase m-2 px-4" onClick="window.close()">Cerrar</button>
            </div>
        </div>
      </div>
    </div>`);
    mainVentana.append(container);
    //Mostrar datos del actor

    let containerProd = container.find(".prodAct");
    let iteprod = data.prodData;
    let production = iteprod.next();
    //Mostrar lista de producciones
    while (!production.done) {
      let p = $(`
            <ul><li "${production.value.getId()}" class="productionFile nav-link" href="#">
            ${production.value.getTitle()}
            
            </li></ul>
            `);
      containerProd.append(p);
      production = iteprod.next();
    }
    window.document.body.scrollIntoView();
  }

  //VENTANA para mostrar la FICHA DE DIRECTOR
  showDirectorFileInNewWindow(data, window) {
    let mainVentana = $(window.document).find("main");
    mainVentana.empty();
    let dir = data.directorData;
    window.document.title = `${dir.getName()}${dir.getLastName1()}`;
    //Datos del director
    let container = $(`<div class="container article-banner"><div class="row">
        <div class="table-responsive" id="shoppingcart-table">
            <table class="table table-sm">
                <thead>
                </br>
                </br>
                    <tr>
                      <th scope="row">Nombre</th>
                      <td >${dir.getName()}</td>
                      <th scope="row">Primer Apellido</th>
                      <td >${dir.getLastName1()}</td>
                      <th scope="row">Segundo Apellido</th>
                      <td >${dir.getLastName2()}</td>
                      <th scope="row">Fecha de nacimiento</th>
                      <td >${dir.getBorn()}</td>
                   </tr>
                </thead>
                <tbody>
                </tbody>      
                <thead>
                <tr >      
                 <th scope="col">Producciones</th>  
                 <td class="prodDir"></td>     
               </tr>
             </thead>
            </table>
            <div> 
            <button class="btn btn-primary text-uppercase m-2 px-4" onClick="window.close()">Cerrar</button>
            </div>
        </div>
      </div>
    </div>`);
    mainVentana.append(container);
    //Mostrar datos del direcctor

    let containerProd = container.find(".prodDir");
    let iteprod = data.prodData;
    let production = iteprod.next();
    //Mostrar lista de producciones
    while (!production.done) {
      let p = $(`
            <ul><li id= "${production.value.getId()}" class="productionFile nav-link" href="#">
            ${production.value.getTitle()}
            </li></ul>
            `);
      containerProd.append(p);
      production = iteprod.next();
    }
    window.document.body.scrollIntoView();
  }

  //MOSTRAR FOMULARIO 1
  showNewProductionForm(data) {
    this.main.empty();
    /* if (this.categories.children().length > 1)
      this.categories.children()[1].remove();*/
    let container = $(`<div id="new-production" class="container my-3">
 <h5 class="display-5">Nueva producción</h5>
 <form name="fNewProduction" role="form" class="row g-3" novalidate>
 <div class="col-md-2">
     <label for="type" class="form-label">Tipo de producción
     <abbr title="required" aria-label="required">*</abbr>
     </label>
     <select id="type" class="form-select" required>
       <option value="" selected>Choose...</option>
       <option  value="movie">Película</option>
       <option  id="serie" value="serie">Serie</option>
     </select>
     <div class="invalid-feedback">El tipo es obligatorio.</div>
		 <div class="valid-feedback">Correcto.</div>
 </div>
 <div class="col-md-6">
     <label for="title" class="form-label">Título
     <abbr title="required" aria-label="required">*</abbr>
     </label>
     <input type="text" class="form-control" id="title" value="" required >
     <div class="invalid-feedback">El título es obligatorio.</div>
		 <div class="valid-feedback">Correcto.</div>
   </div>
   <div class="col-md-6">
     <label for="nacionality" class="form-label">Nacionalidad</label>
     <input type="text" class="form-control" id="nacionality" value="">
   </div>
   <div class="col-md-2">
     <label for="publication" class="form-label">Fecha de estreno
     <abbr title="required" aria-label="required">*</abbr>
     </label>
     <input type="month" class="form-control" id="publication" value="" required>
     <div class="invalid-feedback">la fecha es obligatoria.</div>
		 <div class="valid-feedback">Correcto.</div>
   </div>
   <div class="col-8">
     <label for="synopsis" class="form-label">Sinopsis</label>
     <textarea class="form-control" id="synopsis" value="" ></textarea>
   </div>
   <div class="col-2">
     <label for="season" class="form-label">Nº de temporadas</label>
     <input type="number" class="form-control" id="season" value="">
   </div>
   
   <div class="col-md-6">
     <label for="poster" class="form-label">Póster</label>
     <input type="url" class="form-control" id="poster" value="" placeholder="url...">
   </div>
   <div class="col-md-4">
     <label for="categorySelect" class="form-label">Categoría
     <abbr title="required" aria-label="required">*</abbr>
     </label>
     <select id="categorySelect" class="form-select" required>
       <option value="" selected>Choose...</option>
     </select>
     <div class="invalid-feedback">La categoría es obligatoria.</div>
		 <div class="valid-feedback">Correcto.</div>
   </div>
   <div class="col-md-4">
     <label for="actorSelect" class="form-label">Actores
     <abbr title="required" aria-label="required">*</abbr>
     </label>
     <select id="actorSelect" class="form-select" required multiple>
     </select>
     <div class="invalid-feedback">El reparto es obligatorio.</div>
		 <div class="valid-feedback">Correcto.</div>
   </div>
   <div class="col-md-4">
     <label for="directorSelect" class="form-label">Director
     <abbr title="required" aria-label="required">*</abbr>
     </label>
     <select id="directorSelect" class="form-select" required>
       <option value="" selected>Choose...</option>
     </select>
     <div class="invalid-feedback">El director es obligatorio.</div>
		 <div class="valid-feedback">Correcto.</div>
   </div>
   <div class="col-12">
     <button type="submit" class="btn btn-primary">Enviar datos</button>
     <button class="btn btn-primary" type="reset">Cancelar</button>
   </div>
  </form>
  <div id="mensaje"></div>
  </div>
 `);
    //Director select
    this.main.append(container);
    let directorDropdown = container.find("#directorSelect");

    let iteDir = data.directors;
    let director = iteDir.next();

    while (!director.done) {
      //Dropdown de directores
      let directorSelect = $(`
            <option value= "${director.value.getId()}">${director.value.getName()} ${director.value.getLastName1()}</option>
            `);
      directorDropdown.append(directorSelect);
      director = iteDir.next();
    }

    //Actor select
    let actorDropdown = container.find("#actorSelect");

    let ite = data.actors;
    let actor = ite.next();

    while (!actor.done) {
      //Dropdown de actores
      let actorSelect = $(`
            <option value= "${actor.value.getId()}">${actor.value.getName()} ${actor.value.getLastName1()}</option>
            `);
      actorDropdown.append(actorSelect);
      actor = ite.next();
    }
    //Categoria select
    let categoryDropdown = container.find("#categorySelect");

    let iteCat = data.categories;
    let category = iteCat.next();

    while (!category.done) {
      //Dropdown de directores
      let categorySelect = $(`
             <option value= "${category.value.getId()}" >${category.value.getName()}</option>
             `);
      categoryDropdown.append(categorySelect);
      category = iteCat.next();
    }
  }

  //MOSTRAR FOMULARIO 2
  showDeleteProductionForm(data) {
    this.main.empty();

    let container = $(`<div id="delete-production" class="container my-3">
<h5 class="display-5">Eliminar producción</h5>
<form name="fDeleteProduction" role="form" class="row g-3" novalidate>
<div class="col-md-4">
   <label for="productionSelect" class="form-label">Elige producción
   <abbr title="required" aria-label="required">*</abbr>
   </label>
   <select id="productionSelect" class="form-select" required>
     <option value="" selected>Choose...</option>
   </select>
   <div class="invalid-feedback">Por favor selecciona una producción.</div>
   <div class="valid-feedback">Correcto.</div>
 </div>
 <div class="col-12">
   <button type="submit" class="btn btn-primary">Eliminar producción</button>
   <button class="btn btn-primary" type="reset">Cancelar</button>
 </div>
</form>
</div>
`);
    //Producción select
    this.main.append(container);
    let productionDropdown = container.find("#productionSelect");

    let ite = data.productions;
    let production = ite.next();

    while (!production.done) {
      //Dropdown de directores
      let productionSelect = $(`
          <option value= "${production.value.getId()}">${production.value.getTitle()}</option>
          `);
      productionDropdown.append(productionSelect);
      production = ite.next();
    }
  }

  //MOSTRAR FOMULARIO 3
  showAsignForm(data) {
    //data recibida será una para el assign y otra para el deassign
    this.main.empty();

    let container = $(`<div id="asignaciones" class="container my-3">
<form name="fAssignProduction" role="form" class="row g-3" novalidate>
<div class="col-md-4">
   <label for="productionSelect" class="form-label">Elige producción
   <abbr title="required" aria-label="required">*</abbr>
   </label>
   <select id="productionSelect" class="form-select" required>
     <option value="" selected>Choose...</option>
   </select>
   <div class="invalid-feedback">Por favor selecciona una producción.</div>
   <div class="valid-feedback">Correcto.</div>
 </div>
 <h5 class="display-5">Asignar</h5>
<div class="col-md-4">
     <label for="actorSelect" class="form-label">Actores
     </label>
     <select id="actorSelect" class="form-select" multiple>
     </select>
     <div class="invalid-feedback"></div>
		 <div class="valid-feedback">Correcto.</div>
   </div>
   <div class="col-md-4">
     <label for="directorSelect" class="form-label">Director
     </label>
     <select id="directorSelect" class="form-select">
       <option value="" selected>Choose...</option>
     </select>
     <div class="invalid-feedback"></div>
		 <div class="valid-feedback">Correcto.</div>
   </div>
 <div class="col-12">
   
   <button class="btn btn-primary" type="reset">Cancelar</button>
 </div>
 

</br></br>

<h5 class="display-5">Desasignar</h5>

<div class="col-md-4">
     <label for="actorSelect2" class="form-label">Actores
     </label>
     <select id="actorSelect2" class="form-select" multiple>
     </select>
     <div class="invalid-feedback"></div>
		 <div class="valid-feedback">Correcto.</div>
   </div>
   <div class="col-md-4">
     <label for="directorSelect2" class="form-label">Director
     </label>
     <select id="directorSelect2" class="form-select">
     </select>
     <div class="invalid-feedback"></div>
		 <div class="valid-feedback">Correcto.</div>
   </div>
 <div class="col-12">
   <button type="submit" class="btn btn-primary">Desasignar</button>
   <button class="btn btn-primary" type="reset">Cancelar</button>
 </div>
 </form>

</div>
`);
    //Producción select
    this.main.append(container);
    let productionDropdown = container.find("#productionSelect");
    let ite = data.productions;
    let production = ite.next();

    while (!production.done) {
      //Dropdown de producciones
      let productionSelect = $(`
          <option value= "${production.value.getId()}">${production.value.getTitle()}</option>
          `);
      productionDropdown.append(productionSelect);
      production = ite.next();
    }

    if (data.director != undefined) {
      //Director select
      this.main.append(container);
      let directorDropdown = container.find("#directorSelect2");

      let iteDir = data.director;
      let director = iteDir.next();

      while (!director.done) {
        //Dropdown de directores
        let directorSelect = $(`
       <option value= "${director.value.getId()}">${director.value.getName()} ${director.value.getLastName1()}</option>
       `);
        directorDropdown.append(directorSelect);
        director = iteDir.next();
      }

      //Actor select
      let actorDropdown = container.find("#actorSelect2");

      let iteAct = data.actors;
      let actor = iteAct.next();

      while (!actor.done) {
        //Dropdown de actores
        let actorSelect = $(`
       <option value= "${actor.value.getId()}">${actor.value.getName()} ${actor.value.getLastName1()}</option>
       `);
        actorDropdown.append(actorSelect);
        actor = iteAct.next();
      }
    }
  }
  //Método para enlazar el manejador del enlace de inicio del controlador con la vista
  connectInit(handler) {
    /*$("#init").click((event) => {
            handler();
        });*/
    $(document).on("click", '[id^="init"]', function (event) {
      handler();
    });
    /*$('#init').click((event) => {
			this.#excecuteHandler(handler, [], 'body', {action: 'init'}, '#', event);
		});*/
  }

  connectShowProductionFile(handler) {
    $(document).on("click", '[class^="productionFile"]', function (event) {
      handler($(this).attr("id"));
    });
  }

  connectShowActorFile(handler) {
    $(document).on("click", '[class^="actorFile"]', function (event) {
      handler($(this).attr("id"));
    });
  }

  connectShowDirectorFile(handler) {
    $(document).on("click", '[class^="directorFile"]', function (event) {
      handler($(this).attr("id"));
    });
  }

  connectShowCategories_Productions(handler) {
    $(document).on("click", '[class^="categories"]', function (event) {
      handler($(this).attr("id"));
    });
  }

  //Conectores de los FORMULARIOS
  bindAdminMenu(
    handleNewProductionForm,
    handleDelProductionForm,
    handAddDelPersonForm
  ) {
    $(document).on("click", '[id^="dropdownNewProd"]', function (event) {
      handleNewProductionForm();
    });
    $(document).on("click", '[id^="dropdownDelProd"]', function (event) {
      handleDelProductionForm();
    });
    $(document).on("click", '[id^="dropdownAddPerson"]', function (event) {
      handAddDelPersonForm();
    });
    /*$('#dropdownNewProd').click((event) => {
      this.#excecuteHandler(handNewProduction, [], '#new-production', {action: 'newProduction'}, '#', event);
      });*/
  }

  bindNewProductionForm(handler) {
    newProductionValidation(handler); //Valida el formulario cuando le damos al submit
  }

  bindDelProductionForm(handler) {
    delProductionValidation(handler);
  }

  bindAddDelPersonForm(handle) {
    assignProductionValidation(handle);
  }

  //Conectores de las VENTANAS emergentes
  bindShowInNewWindow(className, handler) {
    $(document).on("click", `[class^="${className}"]`, function (event) {
      this.fileWindow = window.open(
        "file.html",
        "FileWindow",
        "width=800, height=600,top=250, left=250, titlebar=yes, toolbar=no, menubar=no, location=no"
      );
      this.fileWindow.onload = () => {
        handler($(this).attr("id"), this.fileWindow);
      };
      this.fileWindow.focus();
    });
  }

  bindShowProductionInNewWindow(handler) {
    this.bindShowInNewWindow("a-open", handler);
  }

  bindShowActorInNewWindow(handler) {
    this.bindShowInNewWindow("b-open", handler);
  }

  bindShowDirectorInNewWindow(handler) {
    this.bindShowInNewWindow("c-open", handler);
  }

  // Obtiene el elemento objetivo del evento
  /*var elementoPulsado = $(this).attr('id');
             console.log(elementoPulsado.attr('id'));
      var elementoPulsado = $(event.target);
             console.log(elementoPulsado.attr('id'));*/

  /*bindShowProductionInNewWindow(handler) {
    $(document).on("click", '[class^="a-open"]', function (event) {
      this.fileWindow = window.open(
        "file.html",
        "FileWindow",
        "width=800, height=600,top=250, left=250, titlebar=yes, toolbar=no, menubar=no, location=no"
      );
      this.fileWindow.onload = () => {
        handler($(this).attr("id"), this.fileWindow);
      };

      this.fileWindow.focus();
    });
  }
   }
  //Método privado que ejecuta el manejador asociado al evento
  #excecuteHandler(handler, handlerArguments, scrollElement, data, url, event) {
    handler(...handlerArguments);
    $(scrollElement).get(0).scrollIntoView();
    history.pushState(data, null, url);
    event.preventDefault();
  }*/
}

/*<div class="col-md-6">
     <label for="resource" class="form-label">Enlace a recursos</label>
     <input type="url" class="form-control" id="resource" value="" placeholder="url...">
   </div>
   
<div class="col-md-6">
   <h6>Localizaciones</h6>
   <label for="location" class="form-label">Latitud</label>
   <input type="number" class="form-control" id="location" value="" placeholder="Latitud...">
   <label for="location2" class="form-label">Longitud</label>
   <input type="number" class="form-control" id="location2" value="" placeholder="Longitud...">
 </div>*/
