"use strict";
class Resource {
    
    #duration;
    #link;
    constructor(duration, link) {
        this.#duration = duration;
        this.#link = link;

    }
    toString() {
        return this.#duration + " " + this.#link;
    }

    getDuration() {
        return this.#duration;
    }
    setDuration(value) {
        if (value === 'undefined') throw new EmptyValueException("duration");
        this.#duration = value;
    }

    getLink() {
        return this.#link;
    }
    setLink(value) {
        if (value === 'undefined') throw new EmptyValueException("link");
        this.#link = value;
    }
}