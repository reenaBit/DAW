"use strict";

//Declaración objeto Model mediante patrón Singleton
let Model = (function () { //La función anónima devuelve un método getInstance que permite obtener el objeto único
    let instantiated; //Objeto con la instancia única Model

    function init() { //Inicialización del Singleton
        class Model {
            //Definición de atributos privados del objeto
            #products = []; //array con los productos del carrito
            #quantities = []; //array con las cantidades de cada producto del carrito.
            constructor() {
                //La función se invoca con el operador new
                if (!new.target) throw new InvalidAccessConstructorException();
            }

        }
        Object.defineProperty(Model.prototype, "products", { enumerable: true });
        Object.defineProperty(Model.prototype, "quantities", { enumerable: true });

        let sc = new Model();//Devolvemos el objeto Model para que sea una instancia única.
        Object.freeze(sc);
        return sc;
    } //Fin inicialización del Singleton
    return {
        // Devuelve un objeto con el método getInstance
        getInstance: function () {
            if (!instantiated) { //Si la variable instantiated es undefined, priemera ejecución, ejecuta init.
                instantiated = init(); //instantiated contiene el objeto único
            }
            return instantiated; //Si ya está asignado devuelve la asignación.
        }
    };
})();

