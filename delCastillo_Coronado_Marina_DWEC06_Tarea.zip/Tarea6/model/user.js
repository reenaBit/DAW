"use strict";
class User {
    #username;
    #email;
    #password;
    constructor(username, email, password) {
        this.#username = username;
        this.#email = email;
        this.#password = password;


    }
    toString() {
        return this.#username + " " + this.#email + " " + this.#password;
    }

    getUsername() {
        return this.#username;
    }
    setUsername(value) {
        if (value === 'undefined') throw new EmptyValueException("username");
        this.#username = value;
    }

    getEmail() {
        return this.#email;
    }
    setEmail(value) {
        if (value === 'undefined') throw new EmptyValueException("email");
        this.#email = value;
    }
    getPassword() {
        return this.#password;
    }
    setPassword(value) {
        if (value === 'undefined') throw new EmptyValueException("password");
        this.#password = value;
    }


}