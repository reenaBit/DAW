"use strict";

class Production {
    #title;
    #nacionality;
    #publication;
    #synopsis;
    #image;
    #id;
    constructor(title, publication) {

        //Comprobación para que Production sea clase abstracta.
        if ((new.target === Production)) {
            throw new AbstractClassException("Production");
        }
        this.#title = title;
        this.#publication = publication;
        this.#id= this.#generateId();
    }

    #generateId() {
        let id = this.#title.replace(" ","").toLocaleUpperCase();
        return id;
    }

    toString() {
        return this.#title + " " + this.#nacionality + " " + this.#publication + " " + this.#synopsis + " " + this.#image;
    }

    getId(){
        return this.#id;
    }

    getTitle() {
        return this.#title;
    }
    setTitle(value) {
        if (value === 'undefined') throw new EmptyValueException("title");
        this.#title = value;
    }

    getNacionality() {
        return this.#nacionality;
    }
    setNacionality(value) {
        if (value === 'undefined') throw new EmptyValueException("nacionality");
        this.#nacionality = value;
    }

    getPublication() {
        return this.#publication;
    }
    setPublication(value) {
        if (value === 'undefined') throw new EmptyValueException("publication");
        this.#publication = value;
    }
    getSynopsis() {
        return this.#synopsis;
    }
    setSynopsis(value) {
        if (value === 'undefined') throw new EmptyValueException("synopsis");
        this.#synopsis = value;
    }

    getImage() {
        return this.#image;
    }
    setImage(value) {
        if (value === 'undefined') throw new EmptyValueException("image");
        this.#image = value;
    }

}
class Movie extends Production {
    #resource;
    #locations;

    constructor(title, publication) {
        super(title, publication);

    }
    toString() {
        return super.toString + " " + this.#resource + " " + this.#locations;
    }

    getResource() {
        return this.#resource;
    }
    setResources(value) {
        if (value === 'undefined') throw new EmptyValueException("resource");
        this.#resource = value;
    }

    getLocations() {
        return this.#locations;
    }
    setLocations(value) {
        if (value === 'undefined') throw new EmptyValueException("locations");
        this.#locations = value;
    }
}

class Serie extends Production {
    #resources;
    #locations;
    #seasons;
    constructor(title, publication) {
        super(title, publication);
      
    }
    toString() {
        return super.toString + " " + this.#resources + " " + this.#locations + " " + this.#seasons;
    }

    getResources() {
        return this.#resources;
    }
    setResources(value) {
        if (value === 'undefined') throw new EmptyValueException("resources");
        this.#resources = value;
    }

    getLocations() {
        return this.#locations;
    }
    setLocations(value) {
        if (value === 'undefined') throw new EmptyValueException("locations");
        this.#locations = value;
    }
    setSeasons(value) {
        if (value === 'undefined') throw new EmptyValueException("seasons");
        this.#seasons = value;
    }

}