"use strict";

//Declaración objeto AudiovisualDB mediante patrón Singleton
let AudiovisualDB = (function () { //La función anónima devuelve un método getInstance que permite obtener el objeto único
    let instantiated; //Objeto con la instancia única AudiovisualDB

    function init() { //Inicialización del Singleton
        class AudiovisualDB {
            //Definición de atributos privados del objeto
            #systemName;
            #usersList = [];
            #productionsList = [];
            #categoriesList = [];
            #actorsList = [];
            #directorsList = [];
            #categoriesProductions = new Map();
            #actorsProductions = new Map();
            #directorsProductions = new Map();

            constructor() {
                //La función se invoca con el operador new
                if (!new.target) throw new InvalidAccessConstructorException();
            }
            //Método para encontrar la posición del elemento según su id en la lista indicada
            #findPosition(list, id) {
                return list.findIndex((storedElement) => {
                    return (storedElement.getId() === id);
                })
            }

            getSystemName() {
                return this.#systemName;
            }

            setSystemName(value) {
                if (value === "undefined" || value == '') throw new EmptyValueException("systemName");
                this.#systemName = value;
            }

            //////////CATEGORIAS

            addCategory(category) {
                if (category === null || !(category instanceof Category)) throw new ParameterValidationException("category");

                if (this.#findPosition(this.#categoriesList, category.getId()) != -1) {
                    throw new ParamExistsException("category");
                } else {
                    this.#categoriesList.push(category);
                    //añadimos tb el id al map como key y un array vacio como value
                    this.#categoriesProductions.set(category.getId(), []);

                }
                return this;
            }

            getCategories() {
                let nextIndex = 0;
                let array = this.#categoriesList;
                return {
                    next: function () {
                        return nextIndex < array.length ?
                            { value: array[nextIndex++], done: false } :
                            { done: true };
                    }
                }
            }

            removeCategory(category) {
                let index = this.#findPosition(this.#categoriesList, category.getId());
                if (index === -1) {
                    throw new ParamNotExistsException("category");
                } else {
                    this.#categoriesList.splice(index, 1);
                    this.#categoriesProductions.delete(category.getId());
                    return this.#categoriesList.length;
                }
            }

            //////////USUARIOS

            getUsers() {
                let nextIndex = 0;
                let array = this.#usersList;
                return {
                    next: function () {
                        return nextIndex < array.length ?
                            { value: array[nextIndex++], done: false } :
                            { done: true };
                    }
                }
            }

            addUser(user) {
                if (user === null || !(user instanceof User)) throw new ParameterValidationException("user");
                for (let i = 0; i < this.#usersList.length; i++) {
                    if (user.getUsername() === this.#usersList[i].getUsername()) {
                        throw new ParamExistsException("username");
                    }
                    if (user.getEmail() === this.#usersList[i].getEmail()) {
                        throw new ParamExistsException("mail");
                    }
                }
                this.#usersList.push(user);
                return this;
            }

            removeUser(user) {
                if (user === null || !(user instanceof User)) throw new ParameterValidationException("user");

                for (let i = 0; i < this.#categoriesList.length; i++) {
                    if (user === this.#usersList[i]) {
                        let index = this.#usersList.findIndex(function (valor) {
                            return valor == user;
                        });
                        this.#usersList.splice(index, 1);
                        return this.#usersList.length;
                    }
                } throw new ParamNotExistsException("user");
            }

            //////////PRODUCCIONES

            getProductions() {
                let nextIndex = 0;
                let array = this.#productionsList;
                return {
                    next: function () {
                        return nextIndex < array.length ?
                            { value: array[nextIndex++], done: false } :
                            { done: true };
                    }
                }
            }

            addProduction(production) {
                if (production === null || !(production instanceof Production)) throw new ParameterValidationException("production");

                if (this.#findPosition(this.#productionsList, production.getId()) != -1) {
                    throw new ParamExistsException("production");
                } else {
                    this.#productionsList.push(production);
                }
                return this;
            }

            removeProduction(production) {
                if (production === null || !(production instanceof Production)) throw new ParameterValidationException("production");
                let index = this.#findPosition(this.#productionsList, production.getId());
                if (index === -1) {
                    throw new ParamNotExistsException("production");
                } else {
                    this.#productionsList.splice(index, 1);
                    return this.#productionsList.length;
                }
            }

            //////////ACTORS

            getActors() {
                let nextIndex = 0;
                let array = this.#actorsList;
                return {
                    next: function () {
                        return nextIndex < array.length ?
                            { value: array[nextIndex++], done: false } :
                            { done: true };
                    }
                }
            }

            addActor(person) {
                if (person === null || !(person instanceof Person)) throw new ParameterValidationException("actor");
                if (this.#findPosition(this.#actorsList, person.getId()) != -1) {
                    throw new ParamExistsException("actor");
                } else {
                    this.#actorsList.push(person);
                    //añadimos tb el id al map como key y un array vacio como value
                    this.#actorsProductions.set(person.getId(), []);
                }
                return this;
            }

            removeActor(person) {
                let index = this.#findPosition(this.#actorsList, person.getId());
                if (index === -1) {
                    throw new ParamNotExistsException("actor");
                } else {
                    this.#actorsList.splice(index, 1);
                    this.#actorsProductions.delete(person.getId());
                    return this.#actorsList.length;
                }
            }

            //////////DIRECTORS

            getDirectors() {
                let nextIndex = 0;
                let array = this.#directorsList;
                return {
                    next: function () {
                        return nextIndex < array.length ?
                            { value: array[nextIndex++], done: false } :
                            { done: true };
                    }
                }
            }

            addDirector(person) {
                if (person === null || !(person instanceof Person)) throw new ParameterValidationException("director");
                if (this.#findPosition(this.#directorsList, person.getId()) != -1) {
                    throw new ParamExistsException("director");
                } else {
                    this.#directorsList.push(person);
                    //añadimos tb el id al map como key y un array vacio como value
                    this.#directorsProductions.set(person.getId(), []);
                }
                return this;
            }

            removeDirector(person) {
                let index = this.#findPosition(this.#directorsList, person.getId());
                if (index === -1) {
                    throw new ParamNotExistsException("director");
                } else {
                    this.#directorsList.splice(index, 1);
                    this.#directorsProductions.delete(person.getId());
                    return this.#directorsList.length;
                }
            }

            //Método para añadir a un array/value un nuevo value asociado a un key en un map
            addValueToMap = (map, key, newValue) => {
                const array = map.get(key);
                if (array) {
                    array.push(newValue);
                    map.set(key, array);
                }
            }
            //Método para añadir a un array/value un nuevo value asociado a un key en un map
            deleteValueMap = (map, key, deleteValue) => {
                const array = map.get(key);
                const index = array.indexOf(deleteValue);

                array.splice(index, 1);

                map.set(key, array);
            }


            //Los mapas relacionan los id de directores, actores y categorias como key con un array de ids de las producciones como value

            //////////CATEGORIA-PRODUCCIONES
            assignCategory(category, ...production) {
                if (category === null) throw new ParameterValidationException("category");
                let arrayArg = [...production];

                //Comprobamos que tanto la categoria como la producción o producciones estan en sus respectivas listas y si no las añadimos
                if (!this.#categoriesList.includes(category)) {
                    this.addCategory(category);
                }
                for (let production of arrayArg) {
                    if (!this.#productionsList.includes(production)) {
                        this.addProduction(production);
                    }
                }

                //Asociamos id categoria del mapa (ya introducidos en el map) a los id de las producciones introducidas por parámetro
                for (let production of arrayArg) {
                    if (!this.#categoriesProductions.get(category.getId()).includes(production.getId())) {
                        this.addValueToMap(this.#categoriesProductions, category.getId(), production.getId());
                    }
                }
                //return this.#categoriesProductions.get(category.getId()).length;
                return this;
            }

            getProductionsCategory(category) {
                if (category === null) throw new ParameterValidationException("category");

                let idsArray = this.#categoriesProductions.get(category.getId());

                const array = [];
                for (let i = 0; i < this.#productionsList.length; i++) {
                    for (let x = 0; x < idsArray.length; x++) {
                        if (this.#productionsList[i].getId() == idsArray[x]) {
                            array.push(this.#productionsList[i]);
                        }
                    }
                }
                let nextIndex = 0;
                return {
                    next: function () {
                        return nextIndex < array.length ?
                            { value: array[nextIndex++], done: false } :
                            { done: true };
                    }
                }
            }

            deassignCategory(category, ...production) {
                if (category === null) throw new ParameterValidationException("category");
                let arrayArg = [...production];

                //Borramos del id categoria del mapa (ya introducidos en el map) los id de las producciones introducidas por parámetro
                for (let production of arrayArg) {
                    if (this.#categoriesProductions.get(category.getId()).includes(production.getId())) {
                        this.deleteValueMap(this.#categoriesProductions, category.getId(), production.getId());
                    }
                }
                return this.#categoriesProductions.get(category.getId()).length;
            }

            //////////DIRECTORES-PRODUCCIONES
            assignDirector(person, ...production) {
                if (person === null) throw new ParameterValidationException("director");
                let arrayArg = [...production];

                //Comprobamos que tanto la categoria como la producción o producciones estan en sus respectivas listas y si no las añadimos
                if (!this.#directorsList.includes(person)) {
                    this.addDirector(person);
                }
                for (let production of arrayArg) {
                    if (!this.#productionsList.includes(production)) {
                        this.addProduction(production);
                    }
                }

                //Asociamos id categoria del mapa (ya introducidos en el map) a los id de las producciones introducidas por parámetro
                for (let production of arrayArg) {
                    if (!this.#directorsProductions.get(person.getId()).includes(production.getId())) {
                        this.addValueToMap(this.#directorsProductions, person.getId(), production.getId());
                    }
                }
                //return this.#directorsProductions.get(person.getId()).length;
                return this;
            }

            getProductionsDirector(person) {
                if (person === null) throw new ParameterValidationException("director");

                let idsArray = this.#directorsProductions.get(person.getId());

                const array = [];
                for (let i = 0; i < this.#productionsList.length; i++) {
                    for (let x = 0; x < idsArray.length; x++) {
                        if (this.#productionsList[i].getId() == idsArray[x]) {
                            array.push(this.#productionsList[i]);
                        }
                    }
                }
                let nextIndex = 0;
                return {
                    next: function () {
                        return nextIndex < array.length ?
                            { value: array[nextIndex++], done: false } :
                            { done: true };
                    }
                }
            }

            deassignDirector(person, ...production) {
                if (person === null) throw new ParameterValidationException("director");
                let arrayArg = [...production];

                //Borramos del id categoria del mapa (ya introducidos en el map) los id de las producciones introducidas por parámetro
                for (let production of arrayArg) {
                    if (this.#directorsProductions.get(person.getId()).includes(production.getId())) {
                        this.deleteValueMap(this.#directorsProductions, person.getId(), production.getId());
                    }
                }
                return this.#directorsProductions.get(person.getId()).length;
            }

            //////////ACTORES-PRODUCCIONES
            assignActor(person, ...production) {
                if (person === null) throw new ParameterValidationException("actor");
                let arrayArg = [...production];

                //Comprobamos que tanto la categoria como la producción o producciones estan en sus respectivas listas y si no las añadimos
                if (!this.#actorsList.includes(person)) {
                    this.addActor(person);
                }
                for (let production of arrayArg) {
                    if (!this.#productionsList.includes(production)) {
                        this.addProduction(production);
                    }
                }

                //Asociamos id categoria del mapa (ya introducidos en el map) a los id de las producciones introducidas por parámetro
                for (let production of arrayArg) {
                    if (!this.#actorsProductions.get(person.getId()).includes(production.getId())) {
                        this.addValueToMap(this.#actorsProductions, person.getId(), production.getId());
                    }
                }
                //return this.#actorsProductions.get(person.getId()).length;
                return this;
            }

            getProductionsActor(person) {
                if (person === null) throw new ParameterValidationException("actor");

                let idsArray = this.#actorsProductions.get(person.getId());

                const array = [];
                for (let i = 0; i < this.#productionsList.length; i++) {
                    for (let x = 0; x < idsArray.length; x++) {
                        if (this.#productionsList[i].getId() == idsArray[x]) {
                            array.push(this.#productionsList[i]);
                        }
                    }
                }
                let nextIndex = 0;
                return {
                    next: function () {
                        return nextIndex < array.length ?
                            { value: array[nextIndex++], done: false } :
                            { done: true };
                    }
                }
            }

            deassignActor(person, ...production) {
                if (person === null) throw new ParameterValidationException("actor");
                let arrayArg = [...production];

                //Borramos del id categoria del mapa (ya introducidos en el map) los id de las producciones introducidas por parámetro
                for (let production of arrayArg) {
                    if (this.#actorsProductions.get(person.getId()).includes(production.getId())) {
                        this.deleteValueMap(this.#actorsProductions, person.getId(), production.getId());
                    }
                }
                return this.#actorsProductions.get(person.getId()).length;
            }

            getCast(production) {
                if (production === null) throw new ParameterValidationException("production");
                //let idsArray = Object.keys(this.#actorsProductions).filter(key => this.#actorsProductions[key].includes(production));
                //let idsArray = this.#actorsProductions.keys().filter(filter(key => this.#actorsProductions[key].includes(production.getId())));
                let keys = this.#actorsProductions.keys();

                let arrayIdActores = [];
                for (let i = 0; i < this.#actorsProductions.size; i++) {
                    let actorId = keys.next().value;
                    let productionsId = this.#actorsProductions.get(actorId);
                    for (let index = 0; index < productionsId.length; index++) {
                        if (productionsId[index] === production.getId()) {
                            arrayIdActores.push(actorId);
                        }
                    }
                }
                let arrayReparto = [];
                for (let index = 0; index < this.#actorsList.length; index++) {
                    for (let i = 0; i < arrayIdActores.length; i++) {
                        if (this.#actorsList[index].getId() === arrayIdActores[i]) {
                            arrayReparto.push(this.#actorsList[index]);
                        }
                    }
                }

                let nextIndex = 0;
                return {
                    next: function () {
                        return nextIndex < arrayReparto.length ?
                            { value: arrayReparto[nextIndex++], done: false } :
                            { done: true };
                    }
                }
            }

            getDirector(production) {
                if (production === null) throw new ParameterValidationException("production");
                //let idsArray = Object.keys(this.#actorsProductions).filter(key => this.#actorsProductions[key].includes(production));
                //let idsArray = this.#actorsProductions.keys().filter(filter(key => this.#actorsProductions[key].includes(production.getId())));
                let keys = this.#directorsProductions.keys();

                let arrayIdDirectors = [];
                for (let i = 0; i < this.#directorsProductions.size; i++) {
                    let directorId = keys.next().value;
                    let productionsId = this.#directorsProductions.get(directorId);
                    for (let index = 0; index < productionsId.length; index++) {
                        if (productionsId[index] === production.getId()) {
                            arrayIdDirectors.push(directorId);
                        }
                    }
                }
                let arrayDirectores = [];
                for (let index = 0; index < this.#directorsList.length; index++) {
                    for (let i = 0; i < arrayIdDirectors.length; i++) {
                        if (this.#directorsList[index].getId() === arrayIdDirectors[i]) {
                            arrayDirectores.push(this.#directorsList[index]);
                        }
                    }
                }

                let nextIndex = 0;
                return {
                    next: function () {
                        return nextIndex < arrayDirectores.length ?
                            { value: arrayDirectores[nextIndex++], done: false } :
                            { done: true };
                    }
                }
            }


        }

        let adb = new AudiovisualDB();//Devolvemos el objeto AudiovisualDB para que sea una instancia única.
        Object.freeze(adb);
        return adb;
    } //Fin inicialización del Singleton
    return {
        // Devuelve un objeto con el método getInstance
        getInstance: function () {
            if (!instantiated) { //Si la variable instantiated es undefined, priemera ejecución, ejecuta init.
                instantiated = init(); //instantiated contiene el objeto único
            }
            return instantiated; //Si ya está asignado devuelve la asignación.
        }
    };
})();