"use strict";
class Person {
    #name;
    #lastName1;
    #lastName2;
    #born;
    #picture;
    #id;

    constructor(name, lastName1, born) {
        this.#name = name;
        this.#lastName1 = lastName1;
        this.#born = born;
        this.#id= this.#generateId();
        /* if (name === null || lastName1 === null || lastName1 === null) throw new ParameterValidationException("category");*/
    }
    #generateId() {
        let id = this.#name.substring(0, 4).toLocaleUpperCase() + "-" + this.#lastName1.substring(0, 4).toLocaleUpperCase();
        return id;
    }
    toString() {
        return this.name + " " + this.#lastName1 + " " + this.#lastName2 + " " + this.#born + " " + this.#picture;
    }
    getId(){
        return this.#id;
    }
    getName() {
        return this.#name;
    }
    setName(value) {
        if (value === 'undefined') throw new EmptyValueException("name");
        this.#name = value;
    }

    getLastName1() {
        return this.#lastName1;
    }
    setLastName1(value) {
        if (value === 'undefined') throw new EmptyValueException("lastName1");
        this.#lastName1 = value;
    }

    getLastName2() {
        return this.#lastName2;
    }
    setLastName2(value) {
        if (value === 'undefined') throw new EmptyValueException("lastName2");
        this.#lastName2 = value;
    }
    getBorn() {
        return this.#born;
    }
    setBorn(value) {
        if (value === 'undefined') throw new EmptyValueException("born");
        this.#born = value;
    }

    getPicture() {
        return this.#picture;
    }
    setPicture(value) {
        if (value === 'undefined') throw new EmptyValueException("picture");
        this.#picture = value;
    }
}