"use strict";
class Coordinate {
    #latitude;
    #longitude;
    constructor(latitude, longitude) {
        this.#latitude = latitude;
        this.#longitude = longitude;

    }
    toString() {
        return this.#latitude + " " + this.#longitude;
    }

    getLatitude() {
        return this.#latitude;
    }
    setLatitude(value) {
        if (value === 'undefined') throw new EmptyValueException("latitude");
        this.#latitude = value;
    }

    getLongitude() {
        return this.#longitude;
    }
    setLongitude(value) {
        if (value === 'undefined') throw new EmptyValueException("longitude");
        this.#longitude = value;
    }
}