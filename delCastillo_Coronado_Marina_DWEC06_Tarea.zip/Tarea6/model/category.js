"use strict";
(function () {
    class Category {
        #name;
        #description;
        #id;
        constructor(name) {
            this.#name = name;
            this.#id = this.#generateId();
        }
        toString() {
            return this.#name + " " + this.#description;
        }
        #generateId() {
            let id = this.#name.substring(0, 4).toLocaleUpperCase();
            return id;
        }
        getId() {
            return this.#id;
        }

        getName() {
            return this.#name;
        }

        setName(value) {
            if (value === 'undefined') throw new EmptyValueException("name");
            this.#name = value;
        }

        getDescription() {
            return this.#description;
        }
        setDescription(value) {
            if (value === 'undefined') throw new EmptyValueException("description");
            this.#description = value;
        }
    }
    window.Category = Category;

})(); //Invocamos la función global.