"use strict";

class AudiovisualDBController {
  //Campos privados. Estas propiedades son instancias del modelo y la vista
  #modelAudiovisualDB;
  #viewAudiovisualDB;

  constructor(modelAudiovisualDB, viewAudiovisualDB) {
    this.#modelAudiovisualDB = modelAudiovisualDB;
    this.#viewAudiovisualDB = viewAudiovisualDB;
    this.fileWindow = null;
    //Eventos iniciales del controlador

    //Evento que invoca la carga inicial. Tiene que ir el primero
    this.onLoad();
    //Evento que invoca el init de la vista
    this.onInit();
  }
  //Métodos privados
  //Método con la carga inicial
  #loadAudiovisualDB() {
    //////////CATEGORIAS
    let category1 = new Category("Thriller");
    let category2 = new Category("Drama");
    let category3 = new Category("Ciencia Ficción");
    category1.setDescription("pone nervioso");
    category2.setDescription("hace llorar");
    category3.setDescription("te hace pensar");

    this.#modelAudiovisualDB
      .addCategory(category1)
      .addCategory(category2)
      .addCategory(category3);

    //////////PRODUCCIONES
    //Instanciamos resources para poder introducirlas en el constructor de las producciones
    let resourceAvat = new Resource(190, "./rutaRecurso");
    let resourceAB = new Resource(137, "./rutaRecurso");
    let resourceEsdla = new Resource(178, "./rutaRecurso");
    let resource1 = new Resource(178, "./rutaRecurso");
    let resource2 = new Resource(178, "./rutaRecurso");
    let resource3 = new Resource(178, "./rutaRecurso");
    let resource4 = new Resource(178, "./rutaRecurso");

    //En las series los recursos son un array con los recursos de cada capitulo
    let resourceTloACap1 = new Resource(81, "./rutaRecurso");
    let resourceTloACap2 = new Resource(53, "./rutaRecurso");
    let resourceTloACap3 = new Resource(76, "./rutaRecurso");
    let resourcesListTloA = [
      resourceTloACap1,
      resourceTloACap2,
      resourceTloACap3,
    ];
    let resourceTvCap1 = new Resource(55, "./rutaRecurso");
    let resourceTvCap2 = new Resource(58, "./rutaRecurso");
    let resourceTvCap3 = new Resource(60, "./rutaRecurso");
    let resourcesListTv = [resourceTvCap1, resourceTvCap2, resourceTvCap3];
    let resourceWLCap1 = new Resource(55, "./rutaRecurso");
    let resourceWLCap2 = new Resource(58, "./rutaRecurso");
    let resourceWLCap3 = new Resource(60, "./rutaRecurso");
    let resourcesListWL = [resourceWLCap1, resourceWLCap2, resourceWLCap3];
    let resourceYPCap1 = new Resource(55, "./rutaRecurso");
    let resourceYPCap2 = new Resource(58, "./rutaRecurso");
    let resourceYPCap3 = new Resource(60, "./rutaRecurso");
    let resourcesListYP = [resourceYPCap1, resourceYPCap2, resourceYPCap3];
    let resourceSIMPCap1 = new Resource(55, "./rutaRecurso");
    let resourceSIMPCap2 = new Resource(58, "./rutaRecurso");
    let resourceSIMPCap3 = new Resource(60, "./rutaRecurso");
    let resourcesListSIMP = [
      resourceSIMPCap1,
      resourceSIMPCap2,
      resourceSIMPCap3,
    ];

    //Instanciamos locations para poder introducirlas en el constructor de las producciones
    let locationsAvat = new Coordinate(85, 40);
    let locationsAvat2 = new Coordinate(215, 30);
    let locationsAB = new Coordinate(12, 43);
    let locationsEsdla = new Coordinate(75, 90);
    let locationsEsdla2 = new Coordinate(105, 83);
    let locationsTloa = new Coordinate(180, 120);
    let locationsTloa2 = new Coordinate(200, 130);
    let locationsTloa3 = new Coordinate(10, 40);
    let locationsTv = new Coordinate(13, 55);
    let locationsWL = new Coordinate(15, 75);
    let locationsYP = new Coordinate(15, 75);
    let locationsSIMP = new Coordinate(15, 75);
    let locations1 = new Coordinate(15, 75);
    let locations2 = new Coordinate(15, 75);
    let locations3 = new Coordinate(15, 75);
    let locations4 = new Coordinate(15, 75);

    let arraylocationsAvat = [locationsAvat, locationsAvat2];
    let arraylocationsAb = [locationsAB];
    let arraylocationsEsdla = [locationsEsdla, locationsEsdla2];
    let arraylocationsTloa = [locationsTloa, locationsTloa2, locationsTloa3];
    let arraylocationsTv = [locationsTv];
    let arraylocationsSIMP = [locationsSIMP];
    let arraylocationsYP = [locationsYP];
    let arraylocationsWL = [locationsWL];
    let arraylocations1 = [locations1];
    let arraylocations2 = [locations2];
    let arraylocations3 = [locations3];
    let arraylocations4 = [locations4];

    //Instanciamos las producciones que vamos a añadir a la lista. Las propiedades obligatorias pasan por el constructor
    //mientras las no obligatorias se introducen con los setters. Algunas de las no obligatorias no las he metido
    let produccion1 = new Movie("Avatar", new Date(2015, 11, 16));
    produccion1.setNacionality("Estados Unidos");
    produccion1.setSynopsis("Jake Sully y Ney'tiri han formado una familia.");
    produccion1.setImage("./image.jpg");
    produccion1.setResources(resourceAvat);
    produccion1.setLocations(arraylocationsAvat);

    let produccion2 = new Movie("As Bestas", new Date(2015, 12, 16));
    produccion2.setNacionality("España");
    produccion2.setSynopsis(
      "Un conflicto con sus vecinos, hará que la tensión crezca en la aldea."
    );
    produccion2.setImage("./image.jpg");
    produccion2.setResources(resourceAB);
    produccion2.setLocations(arraylocationsAb);

    let produccion3 = new Serie("Tokyo Vice", new Date(2015, 12, 16));
    produccion3.setNacionality("Estados Unidos");
    produccion3.setSynopsis(
      "Jake comienza a investigar el oscuro mundo de la Yakuza"
    );
    produccion3.setImage("./image.jpg");
    produccion3.setResources(resourcesListTv);
    produccion3.setLocations(arraylocationsTv);
    produccion3.setSeasons(2);

    let produccion4 = new Serie("The last of Us", new Date(2015, 12, 16));
    produccion4.setNacionality("Estados Unidos");
    produccion4.setSynopsis(
      "Una chica y un señor en un mundo apocaliptico de zombies"
    );
    produccion4.setImage("./image.jpg");
    produccion4.setResources(resourcesListTloA);
    produccion4.setLocations(arraylocationsTloa);
    produccion4.setSeasons(2);

    let produccion5 = new Movie(
      "El señor de los Anillos",
      new Date(2015, 12, 16)
    );
    produccion5.setNacionality("Estados Unidos");
    produccion5.setSynopsis("Un hobbit tiene que tirar un anillo a un volcán");
    produccion5.setImage("./image.jpg");
    produccion5.setResources(resourceEsdla);
    produccion5.setLocations(arraylocationsEsdla);

    let produccion6 = new Movie("Bullet train", new Date(2015, 12, 16));
    produccion6.setNacionality("Estados Unidos");
    produccion6.setSynopsis(
      "Cinco asesinos a sueldo se encuentran a bordo de un tren bala que viaja de Tokio a Morioka. Los sicarios descubrirán que sus misiones no son ajenas entre sí."
    );
    produccion6.setImage("./image.jpg");
    produccion6.setResources(resource1);
    produccion6.setLocations(arraylocations1);

    let produccion7 = new Movie("American Beauty", new Date(2015, 12, 16));
    produccion7.setNacionality("Estados Unidos");
    produccion7.setSynopsis(
      "Lester Burnham es un cuarentón en crisis, cansado de su trabajo y de su mujer, que despierta de su letargo cuando conoce a la atractiva amiga de su hija, a la que intentará impresionar a toda costa."
    );
    produccion7.setImage("./image.jpg");
    produccion7.setResources(resource2);
    produccion7.setLocations(arraylocations2);

    let produccion8 = new Movie(
      "Todo a la vez en todas partes",
      new Date(2015, 12, 16)
    );
    produccion8.setNacionality("Estados Unidos");
    produccion8.setSynopsis(
      "Una heroína inesperada debe usar sus nuevos poderes para luchar contra los desconcertantes peligros del multiverso y así lograr salvar su mundo."
    );
    produccion8.setImage("./image.jpg");
    produccion8.setResources(resource3);
    produccion8.setLocations(arraylocations3);

    let produccion9 = new Movie("Interestelar", new Date(2015, 12, 16));
    produccion9.setNacionality("Estados Unidos");
    produccion9.setSynopsis(
      "Un grupo de científicos y exploradores, encabezados por Cooper, se embarcan en un viaje espacial para encontrar un lugar con las condiciones necesarias para reemplazar a la Tierra y comenzar una nueva vida allí."
    );
    produccion9.setImage("./image.jpg");
    produccion9.setResources(resource4);
    produccion9.setLocations(arraylocations4);

    let produccion10 = new Serie("The white lotus", new Date(2015, 12, 16));
    produccion10.setNacionality("Estados Unidos");
    produccion10.setSynopsis(
      "Un vistazo a las andanzas de diferentes empleados y huéspedes de un exclusivo resort a lo largo de una trágica semana."
    );
    produccion10.setImage("./image.jpg");
    produccion10.setResources(resourcesListWL);
    produccion10.setLocations(arraylocationsWL);
    produccion10.setSeasons(2);

    let produccion11 = new Serie("The young pope", new Date(2015, 12, 16));
    produccion11.setNacionality("Estados Unidos");
    produccion11.setSynopsis(
      "La historia del joven religioso Lenny Belardo, el primer Papa estadounidense llamado Pío XIII, cuya ascensión parece que fue el resultado de una estrategia simple y efectiva de medios implementada por los Cardenales."
    );
    produccion11.setImage("./image.jpg");
    produccion11.setResources(resourcesListYP);
    produccion11.setLocations(arraylocationsYP);
    produccion11.setSeasons(2);

    let produccion12 = new Serie("Los simpsons", new Date(2015, 12, 16));
    produccion12.setNacionality("Estados Unidos");
    produccion12.setSynopsis(
      "La comedia de dibujos animados se centra en una familia que vive en la ciudad de Springfield. La cabeza de la familia Simpson es Homero, quien no es un hombre de familia típico, obrero de una planta nuclear, él hace lo mejor para poder liderar a su familia, pero frecuentemente se da cuenta que son ellos los que lo mandan."
    );
    produccion12.setImage("./image.jpg");
    produccion12.setResources(resourcesListSIMP);
    produccion12.setLocations(arraylocationsSIMP);
    produccion12.setSeasons(2);

    this.#modelAudiovisualDB
      .addProduction(produccion1)
      .addProduction(produccion2)
      .addProduction(produccion3)
      .addProduction(produccion4)
      .addProduction(produccion5)
      .addProduction(produccion6)
      .addProduction(produccion7)
      .addProduction(produccion8)
      .addProduction(produccion9)
      .addProduction(produccion10)
      .addProduction(produccion11)
      .addProduction(produccion12);

    //////////USUARIOS
    //Instanciamos los usuarios que vamos a añadir a la lista
    let user1 = new User("rafael", "rafael@.com", "passRafa");
    let user2 = new User("marina", "mar@.com", "marpass");
    let user3 = new User("samuel", "samu@.com", "passSam");

    this.#modelAudiovisualDB.addUser(user1).addUser(user2).addUser(user3);

    //////////ACTORS
    //Instanciamos los actores que vamos a añadir a la lista
    let actor1 = new Person("Sigourney", "Weaver", new Date(2015, 12, 16));
    let actor2 = new Person("Cate", "Blanchett", new Date(2015, 12, 16));
    let actor3 = new Person("Luis", "Castro", new Date(2015, 12, 16));
    let actor4 = new Person("Javier", "Bardem", new Date(2015, 12, 16));
    let actor5 = new Person("Penélope", "Cruz", new Date(2015, 12, 16));
    let actor6 = new Person("Laura", "Dern", new Date(2015, 12, 16));
    let actor7 = new Person("Nicole", "Kidman", new Date(2015, 12, 16));
    let actor8 = new Person("Pedro", "Pascal", new Date(2015, 12, 16));
    let actor9 = new Person("Viggo", "Mortensen", new Date(2015, 12, 16));
    let actor10 = new Person("Javier", "Gutierrez", new Date(2015, 12, 16));
    let actor11 = new Person("Brad", "Pitt", new Date(2015, 12, 16));
    let actor12 = new Person("Leornardo", "Di Caprio", new Date(2015, 12, 16));
    let actor13 = new Person("Michele", "Yeoh", new Date(2015, 12, 16));
    let actor14 = new Person("Stephanie", "Hsu", new Date(2015, 12, 16));
    let actor15 = new Person("Harrison", "Ford", new Date(2015, 12, 16));
    let actor16 = new Person("Robert", "De niro", new Date(2015, 12, 16));
    let actor17 = new Person("Meryl", "Streep", new Date(2015, 12, 16));
    let actor18 = new Person("Blanca", "Portillo", new Date(2015, 12, 16));
    let actor19 = new Person("Kate", "Winslet", new Date(2015, 12, 16));
    let actor20 = new Person("Zoe", "Saldaña", new Date(2015, 12, 16));
    let actor21 = new Person("Sam", "Worthington", new Date(2015, 12, 16));
    let actor22 = new Person("Denis", "Menochet", new Date(2015, 12, 16));
    let actor23 = new Person("Matthew", "Mackgonajiu", new Date(2015, 12, 16));
    let actor24 = new Person("Jessica", "Chastain", new Date(2015, 12, 16));

    this.#modelAudiovisualDB
      .addActor(actor1)
      .addActor(actor2)
      .addActor(actor3)
      .addActor(actor4)
      .addActor(actor5)
      .addActor(actor6)
      .addActor(actor7)
      .addActor(actor8)
      .addActor(actor9)
      .addActor(actor10)
      .addActor(actor11)
      .addActor(actor12)
      .addActor(actor13)
      .addActor(actor14)
      .addActor(actor15)
      .addActor(actor16)
      .addActor(actor17)
      .addActor(actor18)
      .addActor(actor19)
      .addActor(actor20)
      .addActor(actor21)
      .addActor(actor22)
      .addActor(actor23)
      .addActor(actor24);

    //////////DIRECTORS
    let director1 = new Person("James", "Cameron", new Date(2015, 12, 16));
    let director2 = new Person("Akira", "Kurosawa", new Date(2015, 12, 16));
    let director3 = new Person("Rodrigo", "Sorogoyen", new Date(2015, 12, 16));
    let director4 = new Person("Craig", "Mazin", new Date(2015, 12, 16));
    let director5 = new Person("Cristopher", "Nolan", new Date(2015, 12, 16));
    let director6 = new Person("Steven", "Spielberg", new Date(2015, 12, 16));
    let director7 = new Person("Pedro", "Almodovar", new Date(2015, 12, 16));
    let director8 = new Person("Martin", "Scorsese", new Date(2015, 12, 16));
    let director9 = new Person("Peter", "Jackson", new Date(2015, 12, 16));
    let director10 = new Person("Taika", "Waititi", new Date(2015, 12, 16));
    let director11 = new Person("Tim", "Burton", new Date(2015, 12, 16));
    let director12 = new Person("Quentin", "Tarantino", new Date(2015, 12, 16));

    this.#modelAudiovisualDB
      .addDirector(director1)
      .addDirector(director2)
      .addDirector(director3)
      .addDirector(director4)
      .addDirector(director5)
      .addDirector(director6)
      .addDirector(director7)
      .addDirector(director8)
      .addDirector(director9)
      .addDirector(director10)
      .addDirector(director11)
      .addDirector(director12);

    //////////CATEGORIA-PRODUCCIONES
    this.#modelAudiovisualDB
      .assignCategory(
        category1,
        produccion2,
        produccion5,
        produccion10,
        produccion7
      )
      .assignCategory(
        category2,
        produccion3,
        produccion12,
        produccion8,
        produccion4
      )
      .assignCategory(
        category3,
        produccion9,
        produccion11,
        produccion6,
        produccion1
      );

    //////////ACTORS-PRODUCCIONES
    this.#modelAudiovisualDB
      .assignActor(actor1, produccion2, produccion5, produccion10, produccion7)
      .assignActor(actor2, produccion3, produccion12, produccion8, produccion4)
      .assignActor(actor3, produccion9, produccion11, produccion6, produccion1)
      .assignActor(actor4, produccion1, produccion2, produccion3, produccion4)
      .assignActor(actor5, produccion3, produccion5, produccion6, produccion7)
      .assignActor(actor6, produccion5, produccion6, produccion7, produccion8)
      .assignActor(actor7, produccion7, produccion8, produccion9, produccion10)
      .assignActor(
        actor8,
        produccion9,
        produccion10,
        produccion11,
        produccion12
      )
      .assignActor(actor9, produccion11, produccion12, produccion1, produccion2)
      .assignActor(actor10, produccion2, produccion5, produccion10, produccion7)
      .assignActor(actor11, produccion3, produccion12, produccion8, produccion4)
      .assignActor(actor12, produccion9, produccion11, produccion6, produccion1)
      .assignActor(actor13, produccion1, produccion2, produccion3, produccion4)
      .assignActor(actor14, produccion3, produccion5, produccion6, produccion7)
      .assignActor(actor15, produccion5, produccion6, produccion7, produccion8)
      .assignActor(actor16, produccion7, produccion8, produccion9, produccion10)
      .assignActor(
        actor17,
        produccion2,
        produccion10,
        produccion11,
        produccion12
      )
      .assignActor(
        actor18,
        produccion11,
        produccion12,
        produccion1,
        produccion2
      )
      .assignActor(actor19, produccion2, produccion5, produccion10, produccion7)
      .assignActor(actor20, produccion3, produccion12, produccion8, produccion4)
      .assignActor(actor21, produccion9, produccion11, produccion6, produccion1)
      .assignActor(actor22, produccion1, produccion2, produccion3, produccion4)
      .assignActor(actor23, produccion3, produccion5, produccion6, produccion7)
      .assignActor(actor24, produccion5, produccion6, produccion7, produccion8);
    //////////DIRECTORS-PRODUCCIONES
    this.#modelAudiovisualDB
      .assignDirector(director1, produccion8)
      .assignDirector(director2, produccion9)
      .assignDirector(director3, produccion10)
      .assignDirector(director4, produccion11)
      .assignDirector(director5, produccion12)
      .assignDirector(director6, produccion1)
      .assignDirector(director7, produccion2)
      .assignDirector(director8, produccion3)
      .assignDirector(director9, produccion4)
      .assignDirector(director10, produccion5)
      .assignDirector(director11, produccion6)
      .assignDirector(director12, produccion7);
  }

  //Métodos del controlador
  //Método que invoca el método de inicializar en la view
  onInit = () => {
    let data = {
      categories: this.#modelAudiovisualDB.getCategories(),
      actors: this.#modelAudiovisualDB.getActors(),
      directors: this.#modelAudiovisualDB.getDirectors(),
      productions: this.#modelAudiovisualDB.getProductions(),
    };
    this.#viewAudiovisualDB.init(data);
    //this.#viewAudiovisualDB.showProductionFile(data);
  };

  //Método que invoca el método privado con la carga inicial.
  onLoad = () => {
    this.#loadAudiovisualDB();
    //Enlace handle con la vista. Si no se hubiese hecho con función flecha hay que indicar que el contexto es el controlador con
    //this.#viewAudiovisualDB.connectInit(this.handleInit.bind(this));
    //El controlador le dice a la vista que lleve a la carga inicial(oninit) por medio de su método/vista del click en el botón de inicio
    this.#viewAudiovisualDB.connectInit(this.handleInit);
    this.#viewAudiovisualDB.connectShowCategories_Productions(
      this.handleShowCategory_Productions
    );
    this.#viewAudiovisualDB.connectShowProductionFile(
      this.handleShowProductionFile
    );
    this.#viewAudiovisualDB.connectShowActorFile(this.handleShowActorFile);
    this.#viewAudiovisualDB.connectShowDirectorFile(
      this.handleShowDirectorFile
    );

    //ventanas
    this.#viewAudiovisualDB.bindShowProductionInNewWindow(
      this.handleShowProductionInNewWindow
    );
    this.#viewAudiovisualDB.bindShowDirectorInNewWindow(
      this.handleShowDirectorInNewWindow
    );
    this.#viewAudiovisualDB.bindShowActorInNewWindow(
      this.handleShowActorInNewWindow
    );

    //formularios
    this.#viewAudiovisualDB.bindAdminMenu(
      this.handleNewProductionForm,
      this.handleDelProductionForm,
      this.handAddDelPersonForm
    );
  };

  //invocador de prueba al cargar
  /*onCategoriesInMainCharged = () => {
         let data = {
            categories: this.#modelAudiovisualDB.getCategories(),
        }
        this.#viewAudiovisualDB.init(data);
       }*/

  //Manejadores
  //Manejador del enlace de inicio. Dispara el evento de carga inicial del contenido
  handleInit = () => {
    this.onInit();
    console.log("hola");
    //console.log(this.#modelAudiovisualDB.this.category1.getId())
  };

  handleShowCategory_Productions = (catId) => {
    let data;
    let iteCat = this.#modelAudiovisualDB.getCategories();
    let category = iteCat.next();
    while (!category.done) {
      category.value.getId();
      if (category.value.getId() == catId) {
        data = {
          productionsCategory: this.#modelAudiovisualDB.getProductionsCategory(
            category.value
          ),
        };
      }
      category = iteCat.next();
    }
    this.#viewAudiovisualDB.showCategories_Productions(data);
  };

  handleShowProductionFile = (prodId) => {
    let data;
    let iteProd = this.#modelAudiovisualDB.getProductions();
    let production = iteProd.next();
    while (!production.done) {
      if (production.value.getId() == prodId) {
        data = {
          prodData: production.value,
          castData: this.#modelAudiovisualDB.getCast(production.value),
          directorData: this.#modelAudiovisualDB.getDirector(production.value),
        };
      }
      production = iteProd.next();
    }
    this.#viewAudiovisualDB.showProductionFile(data);
  };

  handleShowActorFile = (actId) => {
    let data;
    let iteAct = this.#modelAudiovisualDB.getActors();
    let actor = iteAct.next();
    while (!actor.done) {
      if (actor.value.getId() == actId) {
        data = {
          actorData: actor.value,
          prodData: this.#modelAudiovisualDB.getProductionsActor(actor.value),
        };
      }
      actor = iteAct.next();
    }
    this.#viewAudiovisualDB.showActorFile(data);
  };

  handleShowDirectorFile = (dirId) => {
    let data;
    let iteDir = this.#modelAudiovisualDB.getDirectors();
    let director = iteDir.next();
    while (!director.done) {
      if (director.value.getId() == dirId) {
        data = {
          directorData: director.value,
          prodData: this.#modelAudiovisualDB.getProductionsDirector(
            director.value
          ),
        };
      }
      director = iteDir.next();
    }
    this.#viewAudiovisualDB.showDirectorFile(data);
  };

  handleShowProductionInNewWindow = (serial, newWindow) => {
    let data;
    let iteProd = this.#modelAudiovisualDB.getProductions();
    let production = iteProd.next();

    while (!production.done) {
      if (production.value.getId() == serial) {
        data = {
          prodData: production.value,
          castData: this.#modelAudiovisualDB.getCast(production.value),
          directorData: this.#modelAudiovisualDB.getDirector(production.value),
        };
      }
      production = iteProd.next();
    }

    this.#viewAudiovisualDB.showProductionFileInNewWindow(data, newWindow);
  };
  handleShowActorInNewWindow = (id, newWindow) => {
    let data;
    let iteAct = this.#modelAudiovisualDB.getActors();
    let actor = iteAct.next();
    while (!actor.done) {
      if (actor.value.getId() == id) {
        data = {
          actorData: actor.value,
          prodData: this.#modelAudiovisualDB.getProductionsActor(actor.value),
        };
      }
      actor = iteAct.next();
    }
    this.#viewAudiovisualDB.showActorFileInNewWindow(data, newWindow);
  };

  handleShowDirectorInNewWindow = (id, newWindow) => {
    let data;
    let iteDir = this.#modelAudiovisualDB.getDirectors();
    let director = iteDir.next();
    while (!director.done) {
      if (director.value.getId() == id) {
        data = {
          directorData: director.value,
          prodData: this.#modelAudiovisualDB.getProductionsDirector(
            director.value
          ),
        };
      }
      director = iteDir.next();
    }
    this.#viewAudiovisualDB.showDirectorFileInNewWindow(data, newWindow);
  };

  handleNewProductionForm = () => {
    let data;
    data = {
      categories: this.#modelAudiovisualDB.getCategories(),
      directors: this.#modelAudiovisualDB.getDirectors(),
      actors: this.#modelAudiovisualDB.getActors(),
      productions: this.#modelAudiovisualDB.getProductions(),
    };
    this.#viewAudiovisualDB.showNewProductionForm(data);
    this.#viewAudiovisualDB.bindNewProductionForm(this.handleCreateProduction);
  };

  handleDelProductionForm = () => {
    let data;
    data = {
      productions: this.#modelAudiovisualDB.getProductions(),
    };
    this.#viewAudiovisualDB.showDeleteProductionForm(data);
    this.#viewAudiovisualDB.bindDelProductionForm(this.handleDeleteProduction);
  };

  handAddDelPersonForm = (
    idproductionSelected,
    selectedValuesActor,
    directorSelect
  ) => {
    //La primera vez solo se envia la data de las producciones y envío el handle al validation
    let data;
    let productionSelected;
    data = {
      productions: this.#modelAudiovisualDB.getProductions(),
    };
    this.#viewAudiovisualDB.showAsignForm(data);
    this.#viewAudiovisualDB.bindAddDelPersonForm(this.handAddDelPersonForm);

    //El validation devuelve el id de select de producciones y al entrar en el if ya puede devolver la data completa segun esa produccion
    if (idproductionSelected != undefined) {
      console.log("if" + idproductionSelected);
      let ite = this.#modelAudiovisualDB.getProductions();
      let production = ite.next();
      while (!production.done) {
        if (production.value.getId() == idproductionSelected) {
          productionSelected = production.value;
        }
        production = ite.next();
      }
      data = {
        productions: this.#modelAudiovisualDB.getProductions(),
        director: this.#modelAudiovisualDB.getDirector(productionSelected),
        actors: this.#modelAudiovisualDB.getCast(productionSelected),
      };
      this.#viewAudiovisualDB.showAsignForm(data);
      this.#viewAudiovisualDB.bindAddDelPersonForm(this.handAddDelPersonForm);

      console.log(productionSelected);
      //Envío a través de este método los datos al método que desasigna, En lugar de hacerlo desde el validation
      this.handleAddDelPerson(
        productionSelected,
        selectedValuesActor,
        directorSelect
      );
    }
  };

  handleCreateProduction = (
    type,
    title,
    publication,
    categorySelect,
    selectedValuesActor,
    directorSelect,
    nacionality,
    synopsis,
    season,
    poster
  ) => {
    let production;
    let done, error;
    try {
      if (type === "movie") {
        production = new Movie(title, publication);
        done = true;
      } else {
        production = new Serie(title, publication);
        production.setSeasons(season);
        done = true;
      }

      production.setNacionality(nacionality);
      production.setSynopsis(synopsis);
      production.setImage(poster);
      this.#modelAudiovisualDB.addProduction(production); //Añadimos la producción a la lista de producciones

      let ite = this.#modelAudiovisualDB.getCategories();
      let categoria = ite.next();
      while (!categoria.done) {
        if (categoria.value.getId() === categorySelect) {
          this.#modelAudiovisualDB.assignCategory(categoria.value, production); //Asignamos categoría
        }
        categoria = ite.next();
      }
      let ite3 = this.#modelAudiovisualDB.getDirectors();
      let director = ite3.next();
      while (!director.done) {
        if (director.value.getId() === directorSelect) {
          this.#modelAudiovisualDB.assignDirector(director.value, production); //Asignamos director
        }
        director = ite3.next();
      }

      let ite2 = this.#modelAudiovisualDB.getActors();
      let actor = ite2.next();
      while (!actor.done) {
        for (const actorSelect of selectedValuesActor) {
          if (actor.value.getId() === actorSelect) {
            this.#modelAudiovisualDB.assignActor(actor.value, production); //Asignamos actores
          }
        }
        actor = ite2.next();
      }
    } catch (exception) {
      done = false;
      error = exception;
    }
    if (done === true) {
      alert("Nueva producción creada");
    } else {
      alert("Error");
    }
    this.handleNewProductionForm(); //Recargamos el formulario
  };

  handleDeleteProduction = (productionValueForm) => {
    let done, error;
    let productionDel;

    let ite = this.#modelAudiovisualDB.getProductions();
    let production = ite.next();
    while (!production.done) {
      if (production.value.getId() === productionValueForm) {
        productionDel = production.value;
      }
      production = ite.next();
    }
    try {
      this.#modelAudiovisualDB.removeProduction(productionDel);
      done = true;
    } catch (exception) {
      done = false;
      error = exception;
    }

    if (done === true) {
      alert("Producción eliminada");
    }

    this.handleDelProductionForm(); //Recargamos el formulario
  };

  handleAddDelPerson = (
    productionSelected,
    selectedValuesActor,
    directorSelect
  ) => {
    let done, error;
    console.log("hola entra aqui");

    try {
      if (directorSelect != undefined) {
        console.log("hola entra en el if");

        let ite3 = this.#modelAudiovisualDB.getDirectors();
        let director = ite3.next();
        while (!director.done) {
          if (director.value.getId() === directorSelect) {
            this.#modelAudiovisualDB.deassignDirector(
              director.value,
              productionSelected
            );
          }
          director = ite3.next();
        }
        done = true;
      }
      /*if (selectedValuesActor != undefined) {
        let ite2 = this.#modelAudiovisualDB.getActors();
        let actor = ite2.next();
        while (!actor.done) {
          for (const actorSelect of selectedValuesActor) {
            if (actor.value.getId() === actorSelect) {
              this.#modelAudiovisualDB.deassignActor(
                actor.value,
                productionSelected
              );
            }
          }
          actor = ite2.next();
        }
        done = true;
      }*/
    } catch (exception) {
      done = false;
      error = exception;
    }
    let idproductionSelected = productionSelected.getId();
    if (done === true) {
      alert("Desasignación completada");
    }
    /*this.handAddDelPersonForm(
      
    );*/
  };
}

//Instancia del controlador almacenado en una constante
$(function () {
  const AudiovisualDBApp = new AudiovisualDBController(
    AudiovisualDB.getInstance(),
    new AudiovisualDBView()
  );
  /* history.replaceState({action: 'init'}, null);
	window.addEventListener('popstate', function(event) {
		if (event.state){
			switch (event.state.action){
				case 'init':
					AudiovisualDBApp.handleInit();
					break;
				case 'showShoppingCart':
					ShoppingCartApp.handleShowShoppingCart();
					break;
				case 'productsCategoryList':
					ShoppingCartApp.handleProductsCategoryList(event.state.category);
					break;
				case 'productsTypeList':
					ShoppingCartApp.handleProductsTypeList(event.state.type);
					break;
				case 'showProduct':
					ShoppingCartApp.handleShowProduct(event.state.serial);
					break;
				case 'newProduction':
					AudiovisualDBApp.handleNewProductionForm();
					break;
				case 'removeCategory':
					ShoppingCartApp.handleRemoveCategoryForm();
					break;
				case 'newProduct':
					ShoppingCartApp.handleNewProductForm();
					break;
				case 'removeProduct':
					ShoppingCartApp.handleRemoveProductForm();
					break;
				case 'removeProductByType':
					ShoppingCartApp.handleRemoveProductForm();
					ShoppingCartApp.handleRemoveProductListByType(event.state.type);
					break;
				case 'removeProductByCategory':
					ShoppingCartApp.handleRemoveProductForm();
					ShoppingCartApp.handleRemoveProductListByCategory(event.state.category);
					break;
			}
		}
	});*/
});
