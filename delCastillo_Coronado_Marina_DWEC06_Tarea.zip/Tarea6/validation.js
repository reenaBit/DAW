//Mostrar retroalimentación
function showFeedBack(input, valid, message) {
  let validClass = valid ? "is-valid" : "is-invalid";
  let div = valid
    ? input.nextAll("div.validfeedback")
    : input.nextAll("div.invalid-feedback");
  input.nextAll("div").removeClass("d-block");
  div.removeClass("d-none").addClass("d-block");
  input.removeClass("is-valid is-invalid").addClass(validClass);
  if (message) {
    div.empty();
    div.append(message);
  }
}

//Validación por defecto
function defaultCheckElement(event) {
  this.value = this.value.trim();
  if (!this.checkValidity()) {
    showFeedBack($(this), false);
  } else {
    showFeedBack($(this), true);
  }
}

//Validación formulario AÑADIR producción
function newProductionValidation(handler) {
  let form = document.forms.fNewProduction;
  $(form).attr("novalidate", true); //El navegador no ejecutará las validaciones predeterminadas
console.log(this.season.value);
  $(form).submit(function (event) {
    let isValid = true;
    let firstInvalidElement = null;

    if (!this.type.checkValidity()) {
      isValid = false;
      showFeedBack($(this.type), false);
      firstInvalidElement = this.type;
    } else {
      showFeedBack($(this.type), true);
    }

    if (!this.title.checkValidity()) {
      isValid = false;
      showFeedBack($(this.title), false);
      firstInvalidElement = this.title;
    } else {
      showFeedBack($(this.title), true);
    }

    if (!this.publication.checkValidity()) {
      isValid = false;
      showFeedBack($(this.publication), false);
      firstInvalidElement = this.publication;
    } else {
      showFeedBack($(this.publication), true);
    }

    if (!this.categorySelect.checkValidity()) {
      isValid = false;
      showFeedBack($(this.categorySelect), false);
      firstInvalidElement = this.categorySelect;
    } else {
      showFeedBack($(this.categorySelect), true);
    }

    if (!this.actorSelect.checkValidity()) {
      isValid = false;
      showFeedBack($(this.actorSelect), false);
      firstInvalidElement = this.actorSelect;
    } else {
      showFeedBack($(this.actorSelect), true);
    }

    if (!this.directorSelect.checkValidity()) {
      isValid = false;
      showFeedBack($(this.directorSelect), false);
      firstInvalidElement = this.directorSelect;
    } else {
      showFeedBack($(this.directorSelect), true);
    }

    /*$(document).on("click", '[id^="this.type"]', function (event) {
      console.log("esto es una prueba");
      if (this.type.value === "movie") {
        $("#season").prop("disabled", false);
      } else if (this.type.value === "serie") {
        this.season.disabled = true;
      }
    });*/

    if (!isValid) {
      firstInvalidElement.focus();
    } else {
      const selectedValuesActor = Array.from(actorSelect.selectedOptions).map(
        (option) => option.value
      ); // Obtener los valores seleccionados del select de actores que es multiple
      handler(
        this.type.value,
        this.title.value,
        this.publication.value,
        this.categorySelect.value,
        selectedValuesActor,
        this.directorSelect.value,
        this.nacionality.value,
        this.synopsis.value,
        this.season.value,
        this.poster.value
      );
    }
    event.preventDefault();
    event.stopPropagation();
  });

  /*$(form.type).change(defaultCheckElement);
	$(form.title).change(defaultCheckElement);
	$(form.publication).change(defaultCheckElement);
	$(form.categorySelect).change(defaultCheckElement);
	$(form.actorSelect).change(defaultCheckElement);
	$(form.directorSelect).change(defaultCheckElement);*/
}

//Validación formulario BORRAR producción
function delProductionValidation(handler) {
  let form = document.forms.fDeleteProduction;
  $(form).attr("novalidate", true); 
  $(form).submit(function (event) {
    let isValid = true;
    let firstInvalidElement = null;

    if (!this.productionSelect.checkValidity()) {
      isValid = false;
      showFeedBack($(this.productionSelect), false);
      firstInvalidElement = this.productionSelect;
    } else {
      showFeedBack($(this.productionSelect), true);
    }

    if (!isValid) {
      firstInvalidElement.focus();
    } else {
      handler(this.productionSelect.value);
    }
    event.preventDefault();
    event.stopPropagation();
  });

}

//Validación formulario ASIGNAR/DESASIGNAR producción
function assignProductionValidation(handle) {
  let form = document.forms.fAssignProduction;
  $(form).attr("novalidate", true);
  
  //Enviamos el valor del select de producciones para sacar solo los actores y director que ya están asignados
  let selectedProduction;
  $(form).on("change", '[id^="productionSelect"]', function (event) {
    // Guarda el valor seleccionado del select en la variable selectedProduction
    selectedProduction = $(this).val();
    handle(selectedProduction);
  });

  $(form).submit(function (event) {
    console.log("validation"+this.directorSelect2.value);
    let isValid = true;
    let firstInvalidElement = null;

    if (!this.productionSelect.checkValidity()) {
      isValid = false;
      showFeedBack($(this.productionSelect), false);
      firstInvalidElement = this.productionSelect;
    } else {
      showFeedBack($(this.productionSelect), true);
    }

    if (!this.actorSelect2.checkValidity()) {
      isValid = false;
      showFeedBack($(this.actorSelect2), false);
      firstInvalidElement = this.actorSelect2;
    } else {
      showFeedBack($(this.actorSelect2), true);
    }

    if (!this.directorSelect2.checkValidity()) {
      isValid = false;
      showFeedBack($(this.directorSelect2), false);
      firstInvalidElement = this.directorSelect2;
    } else {
      showFeedBack($(this.directorSelect2), true);
    }

    if (!isValid) {
      firstInvalidElement.focus();
    } else {
      const selectedValuesActor = Array.from(actorSelect2.selectedOptions).map(
        (option) => option.value
      ); // Obtener los valores seleccionados del select de actores que es multiple
      console.log("validation"+this.directorSelect2.value);

      handle(
        selectedProduction,
        selectedValuesActor,
        this.directorSelect2.value
      );
    }
    event.preventDefault();
    event.stopPropagation();
  });


}
